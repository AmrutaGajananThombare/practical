#include <stdio.h>
#include <stdlib.h>

/**
 * * @brief This function reads a specified number of integers from the user and stores them in a dynamically allocated array.
 * * It allocates memory for an integer array of size 'n' and then reads the numbers from standard input, storing them in the allocated memory.
 * * @param n The number of elements to read.
 * @return A pointer to the dynamically allocated integer array.
 */
// TODO: Write your function here as stated above
int*read_numbers (int n)
{  
    if (n<=0)
    {
        return NULL;
    }
int*array =(int*)malloc (n* sizeof (int));
    if (array == NULL)
    { 
        return NULL;
    }
    printf("enter %d intger:\n",n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&array [i]);
    }
     return array;
}     


/**
 * @brief Calculates the average of numbers in a given array.
 * * This function iterates through the array, sums up all the elements, and then calculates the average.
 * The average is returned as a double to handle potential fractional results.
 * * @param array A pointer to the integer array.
 * @param n The number of elements in the array.
 * @return The average of the numbers as a double.
 */
// TODO: Write your function here as stated above
double calculate_average(int*numbers,int n)
{  
    int sum=0,average;
    for (int i=0;i<n;i++)
    {
        sum=sum+numbers[i];
        average=sum/n;
    }
    
     return average;
}     

/**
 * @brief Main function to execute the program.
 * * This function reads the number of elements, calls the read_numbers function to get the
 * array, and then calls calculate_average to find the average. Finally, it frees the dynamically allocated memory
 * and prints the result.
 * * @return 0 upon successful execution.
 */
int main() {
    int n;
    
    
    scanf("%d", &n);

    // Validate the input to avoid issues with negative or zero elements
    if (n <= 0) {
        printf("Number of elements must be a positive integer.\n");
        return 1;
    }

    // Call the function to read numbers and store them in the dynamically allocated array
    int *numbers = read_numbers(n);

    if (numbers == NULL) {
        return 1; // Exit if memory allocation failed
    }

    // Call the function to calculate the average
    double average = calculate_average(numbers, n);
    printf("%.2f\n", average);

    // Free the dynamically allocated memory to prevent memory leaks
    free(numbers);
    numbers = NULL; // Best practice: set the pointer to NULL after freeing

    return 0;
}